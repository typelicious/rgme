# RGME Game Exposé 07 — Climate City 2100

**Version:** 0.1 · **Datum:** 2026-11-06 · **Status:** Konzept-/Nachfragehypothese, nicht validiert  
**Portfolio:** RGME v2.2 · **Archetyp:** Klimaresilienz-Städtebau

## 1. High Concept

**Logline:** Eine Küstenstadt muss Hitze, Starkregen und Zuwanderung bewältigen, ohne soziale Teilhabe aufzugeben.

**Historische Mechanik-Inspiration:** SimCity / City Builder. Die Referenz bezeichnet ein Genre-/Mechanik-Muster, keine geplante Übernahme von Code, Figuren, Karten, Assets oder Titeln.

**USP-Hypothese:** Zonenplanung, Infrastruktur, Risiko- und Zufriedenheitsindikatoren mit Szenariokarten.

## 2. Spielerlebnis und Designpfeiler

1. **Sofort verständlicher Einstieg:** erste bedeutungsvolle Entscheidung innerhalb von 60 Sekunden.
2. **Eine klar erkennbare Kernschleife:** Zonenplanung, Infrastruktur, Risiko- und Zufriedenheitsindikatoren mit Szenariokarten.
3. **Wiederholbarkeit:** variable Szenarien, Entscheidungen und nachvollziehbares Feedback.
4. **Eigenständige Identität:** originäre Welt, Interface, Musik, Charaktere und audiovisuelle Sprache.

**Kernschleife:** Situation erfassen → knappe Ressource oder Option wählen → Simulation ausführen → Konsequenzen sichtbar machen → Strategie anpassen.

**Zielgruppe (Hypothese):** City-Builder- und Bildungsmarkt. **Primärkanal:** Browser, White Label.

## 3. Spielsysteme und MVP-Scope

**MVP Vertical Slice:** Ein Stadtteil, drei Risiken, zehn Bauobjekte.

**Muss-Funktionen:** Tutorial, Save/Resume, responsives UI soweit praktikabel, Ereignis-Logging, Fehlertelemetrie mit Einwilligungs-/Datenschutzkonzept, 1 klarer Erfolgs-/Fehlschlagzustand, 5 automatisierte Smoke-Tests.

**Nicht im MVP:** umfangreiche Kampagne, Multiplayer, Echtgeldwirtschaft, generative Live-Inhalte ohne Moderation, komplexe Accounts.

## 4. Art Direction und Narrative

Klar lesbare, moderne 2D-Ästhetik mit bewussten Retro-Anklängen; keine Nachzeichnung historischer Sprites oder Screenshots. Tonalität und UI werden in einem eigenständigen Moodboard getestet. Story und Fraktionen werden vor Produktionsstart in einer Originalitätsprüfung dokumentiert.

## 5. Demand & Evidence Plan

**Status:** Keine titelbezogenen Live-Demand-Daten erhoben; nachfolgende Aussagen sind zu testende Hypothesen.

- **Historical signal:** Bekanntheit der Mechanik über zeitgenössische Reviews, Community-Erinnerung und historische Veröffentlichungen; Quellenqualität und Rechte separat erfassen.
- **Modern comparables:** mindestens fünf aktuelle Spiele desselben Mechanikclusters; für jedes Steam-Reviews, öffentliche Spielertrends, Release-Alter, Preis, Plattform und Unsicherheiten erfassen.
- **Theme signal:** Google Trends, YouTube-Suchinteresse, Reddit-Diskussionen, Nachrichten-Lebensdauer; normalisieren und Bot-/News-Spikes markieren.
- **Intent signal:** Landingpage-CTR, Play-CTA, Newsletter-Opt-in, 60-Sekunden-Playrate, D1/D7-Retention, Wiederkehr.
- **Commercial signal:** Test von Werbung versus optionalem Premiumzugang; niemals aus Suchvolumen direkt Umsatz ableiten.

**Go/No-Go-Experiment:** Zwei klar unterschiedliche Positionierungen als Landingpages, je ein Gameplay-Clip und ein spielbarer 3–5-Minuten-Slice. Entscheidung anhand vorab definierter Mindeststichprobe und Kanal-basierter Konversionsraten; Benchmarks erst nach eigener Baseline festlegen.

## 6. Publishing & Monetization

**Kanäle:** Browser, White Label; externe Portale nur nach SDK-, Lizenz- und Zulassungsprüfung.  
**Modelle:** zunächst kostenloser Demo-/Portalzugang; danach optionale Premiumversion, B2B-Lizenz oder White Label nach nachgewiesener Nachfrage. Affiliate- und Werbeintegrationen mit Kennzeichnung, Consent und Plattformregeln.

**Cross-Promotion:** thematisch passende Kurzclips, Creator-Tests und eigene Arcade; Tractioneer als optionaler Distribution-Adapter mit Attribution und Frequency Caps.

## 7. IP, Ethik und Risiken

**Originality Gate:** Klimamodelle als didaktische Vereinfachung deklarieren. Die Ähnlichkeit von Mechaniken allein ersetzt keine Prüfung der konkreten Gestaltung, Marken, Figuren, Story, Musik und Assets.  
**Hauptrisiko:** Erklärbarkeit von Ursache-Wirkung.  
**Weitere Risiken:** Plattform-Fit, Akquisekosten, Session-Ökonomie, lokalisierbare UX, Performance auf Mobilgeräten.

## 8. Umsetzungs- und Testplan

- **Discovery (2–4 Tage):** Mechanikgraph, fünf Vergleichstitel, Quellen-/Rechte-Matrix, Risiko-Register.
- **Prototype (5–10 Tage):** spielbare Kernschleife mit instrumentierten Events.
- **Validation (1–2 Wochen):** kleine kontrollierte Traffic-Tests, qualitativer Playtest, Abbruchanalyse.
- **Gate:** nur bei reproduzierbarem Interesse und akzeptabler Produktionsökonomie in den Ausbau.

## 9. Offene Entscheidungen

Welche zwei Kernmechaniken sind unverzichtbar? Welche Zielgruppe soll zuerst getestet werden? Wie groß ist das erste Traffic-Budget? Welcher Vertriebskanal besitzt die geringste Eintrittshürde? Welche IP-/Policy-Risiken sind vor Veröffentlichung extern zu prüfen?

---
*Alle Zahlen zur Entwicklungsdauer sind Planungshypothesen; kein Umsatz oder Marktpotenzial ist hier als gemessen ausgewiesen.*
