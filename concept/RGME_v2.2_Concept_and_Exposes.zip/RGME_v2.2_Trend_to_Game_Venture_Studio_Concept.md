# RGME v2.2 — AI-Native Trend-to-Game Intelligence & Autonomous Game Venture Studio

**Version:** 2.2 · **Datum:** 2026-11-06 · **Status:** Strategisches und technisches Concept Paper · **Vorgänger:** RGME v2.0/v2.1

## 0. Executive Summary

RGME ist ein **evidenzgesteuertes Game Venture Studio**: Eine wachsende Datenbank historischer Spielmechaniken wird mit modernen Marktvergleichstiteln und kulturellen Trends verbunden, um originäre Spielkonzepte zu finden, zu testen, browser-first zu produzieren, kanalübergreifend zu vertreiben und anhand realer Performance zu verbessern. **Nicht** Ziel ist das unautorisierte Neuveröffentlichen historischer Spiele oder die Annahme, dass virale Nachrichten automatisch Spielnachfrage erzeugen.

Die entscheidende Innovation ist ein überprüfbarer Kreislauf **Mechanics → Theme → Audience → Evidence → Prototype → Distribution → Outcomes → Model Update**. Menschliche Freigaben bleiben bei IP, sensiblen Themen, Budget und Veröffentlichung zwingend.

## 1. Mission, Marktpositionierung und strategische Grenzen

**Mission:** Bewährte Spielsysteme mit zeitgemäßen Themen und Zielgruppen kombinieren und in eigenständige, wirtschaftlich testbare Spiele übersetzen.  
**Positionierung:** Game-intelligence + rapid prototyping + multi-channel publishing + B2B white-label.  
**Differenzierungshypothese:** Proprietäre, versionierte Mechanics-/Opportunity-Daten mit Outcome-Feedback statt bloß massenhafter KI-Spielgenerierung.

**Drei Produktlinien:** (A) Evergreen Games mit langfristiger Retention, (B) Trend Editions mit begrenztem Zeitfenster und schneller Produktion, (C) satirische/experimentelle Short-Form-Games. B2B-Angebote: White-Label Arcade, branded games, Bildungs-/Publisher-Lizenzen. Ein Portfolio aus wenigen nachweislich funktionierenden Engines ist sinnvoller als dutzende ungetestete Einzelspiele.

**Nicht-Ziele v2.2:** Eigener vollständiger Amiga-Emulator; automatisches Publizieren ohne Review; reale Konfliktpropaganda; Nachbau geschützter Spielelemente; unkalibrierte Umsatzversprechen.

## 2. Systemlandkarte

```text
Historical Sources ──> Mechanics Registry ─┐
Modern Game Signals ─> Demand/Evidence ────┼─> Game Opportunity Graph
Cultural Trend Feeds ─> Trend Intelligence ┘          │
                                                       v
                                              Idea & Portfolio Engine
                                                       │
                                           Originality / Ethics Gate
                                                       │
                                               Prototype Factory
                                                       │
                                             Playtest & Forecast
                                                       │
                                              Human Release Gate
                                                       │
                                     Browser / Portal / Native / B2B
                                                       │
                                         Attribution & Game Analytics
                                                       └──> Evidence Store
```

**Cross-cutting:** SkillWeave (Lifecycle/Task Ledger/Gates), research-core, evidence-core, source-policy, experiment-core, attribution-core; Rust für Analyse- und Simulationsmodule, Web-Frontend für Arcade, Postgres für relationale Daten, Objekt-Storage für Assets, optional Graphprojektion für Mechanikbeziehungen.

## 3. Historical Game Intelligence / Mechanics Registry

**Entitäten:** HistoricalTitle, Release, Platform, RightsClaim, Mechanic, MechanicPattern, Genre, PlayLoop, PlayerMotivation, DifficultyCurve, SessionShape, VisualConvention, Source, Observation, Confidence.  
**Beziehungen:** `TITLE_EXHIBITS_MECHANIC`, `MECHANIC_COMPOSES_LOOP`, `TITLE_INSPIRED_BY`, `MECHANIC_COMPARES_TO`, `EVIDENCE_SUPPORTS_CLAIM`.

**Ingestion:** RGME Library Identity Registry als deterministischer Schlüssel; Rechte-Audits aus bestehenden Batches als separater, versionierter Input; manuell kuratierte Mechanik-Taxonomie. Spielbeobachtung nur aus rechtmäßig beschafften Quellen; Ghidra/REA nur bei autorisiertem Analysezweck. Hardwareemulation dient als instrumentierte Beobachtungsumgebung, nicht als Produktkern.

**Mechanikmodell:** Trigger → Actor → Action → Preconditions → State Transition → Feedback → Reward/Penalty → Session Context. Game Behavior IR (GBIR) erfasst beobachtetes Verhalten; die Mechanik-Taxonomie abstrahiert es von geschützter Gestaltung. Provenienz und Konfidenz sind Pflichtfelder.

## 4. Contemporary Game Demand & Evidence (DEIL)

**Quellfamilien:** Steam Store/SteamDB/öffentliche Charts (mit Nutzungsbedingungen), Plattformcharts, itch.io, öffentlich zugängliche Portalrankings, YouTube/Reddit, Suchtrends, Review-Text, Preis- und Veröffentlichungsdaten, eigene Arcade-Telemetrie. Keine Datenquelle ist allein repräsentativ.

**Metriktrennung:** (a) Supply: Veröffentlichungen/Tags, (b) Attention: Such- und Gesprächsvolumen, (c) Interest: Wishlists/Trailer-Klicks, (d) Play: Starts/Completion/Retention, (e) Revenue: tatsächliche ARPDAU/Abos/Lizenzen. Reviews sind nur unsichere Proxies für Verkäufe; CCU ist keine Unique-Reichweite; Trendindex ist kein absolutes Suchvolumen.

**Evidence Contract:** Jede Zahl enthält `source_url`, `retrieved_at`, `observed_period`, `metric_definition`, `geography`, `platform`, `sample`, `license_terms`, `confidence`, `transform_version` und `limitations`. Rohdaten unverändert aufbewahren, normalisierte Features getrennt ableiten. Kein erfundener Marktwert.

## 5. Cultural & Trend Intelligence (TGI)

**Quellen:** Nachrichtenkategorien, Google Trends, öffentliche Video-/Community-Diskussionen, Wissenschafts-/Technologietrends, saisonale Ereignisse, Creator-Memes; nur erlaubte APIs und ToS-konforme Zugriffe.  
**Pipeline:** Topic extraction → Entity linking → deduplication → language/region tagging → momentum/time decay → controversy & sensitivity detection → audience overlap → mechanic fit.

**Trend Features:** relative Suchdynamik, Mehrquellen-Bestätigung, Persistenz, geographische Verteilung, Sentiment-Polarisation, Gaming-Community-Overlap, erwartete Halbwertszeit, saisonale Wiederkehr. Vermeide Trending-Spikes als Nachfragebeweis. Politische und konfliktbezogene Themen benötigen explizites Redaktions-Gate; reale Tragödien nicht opportunistisch gamifizieren.

## 6. Game Opportunity Graph (GOG)

**Knoten:** HistoricalTitle, Mechanic, Loop, ModernComparable, Topic, Audience, Channel, MonetizationModel, Concept, Experiment, Outcome, Risk.  
**Kanten:** `SHARES_MECHANIC`, `FITS_THEME`, `APPEALS_TO`, `DISTRIBUTABLE_ON`, `SUPPORTED_BY`, `CONFLICTS_WITH`, `VALIDATED_BY`.  
**Ranking:** Retrieval über Mechanikähnlichkeit und Zielgruppenüberschneidung; LLM-generierte Hypothesen werden als Hypothesen gespeichert und dürfen Evidence nicht überschreiben. Gegenproben und Negativbeispiele sind obligatorisch.

**Opportunity Score (nur Screening, nicht Umsatzforecast):** 25 % moderne Gaming-Nachfrage, 20 % Mechanic–Theme-Fit, 15 % Trendpersistenz, 15 % Channel-Fit, 10 % Monetarisierung, 10 % Produktionsmachbarkeit, 5 % historische Resonanz. Fehlende Daten erzeugen Unsicherheitsabzüge; Sensitivitätsanalyse zeigt Rankingänderungen. IP-, Persönlichkeitsrechts-, Safety- und Plattformrisiken sind **harte Gates**, nicht kompensierbare Score-Punkte.

## 7. Reichweiten- und Umsatzprognose: Evidence statt Scheingenauigkeit

**Funnel pro Kanal:** Impressions → Clicks → Landing Sessions → Qualified Starts → Engaged Plays → D1/D7 Return → Monetizable Sessions → Revenue.  
**Basismodell:** `starts = impressions × CTR × start_conversion`; `engaged = starts × engagement_rate`; `ad_revenue = eligible_ad_impressions / 1000 × net_eCPM`; `subscription_revenue = paying_users × net_ARPPU`; `affiliate_revenue = attributable_clicks × approved_conversion × net_commission`. Diese Formeln liefern nur dann eine Prognose, wenn Eingangsverteilungen empirisch belegt sind.

**Unsicherheit:** Drei Szenarien (P10/P50/P90), nicht willkürliche „optimistische“ Werte; Monte-Carlo mit Beta-Verteilungen für Conversions, empirischen Spannen für CPM und Kosten. Kanalabhängigkeiten modellieren, Doppelzählung vermeiden, Kohorten nach Release und Trafficquelle trennen. Bei Datenmangel nur Sensitivitätsbereiche und **Forecast unavailable** ausgeben.

**Kalibrierung:** Erste 3–5 Pilotspiele liefern kanal- und genrebezogene Baselines; wöchentlich Brier Score/Calibration Error für Go/No-Go-Prognosen, Forecast Error für Starts und Net Revenue. Holdout-Tests gegen triviale Baselines (Genre-Median, simple Trendranking) verhindern Pseudo-Intelligenz.

**Vorproduktions-Evidenzleiter:** E0 Idee → E1 Desk Research → E2 vergleichbare Nachfrage → E3 Landingpage/Trailer-Test → E4 spielbarer Slice → E5 Kohortenretention → E6 wiederholbare Monetarisierung. Jeder Gate-Entscheid dokumentiert Evidenzstand und Gegenargumente.

## 8. Idea Engine, Originality-by-Design und Editorial Policy

**Ideation:** Mechanic cluster × Theme × Audience × Session format × Distribution channel. Generator liefert 10 Konzepte, Deduplicator bündelt Varianten, Kritiker prüft technische Machbarkeit, kulturelle Sensibilität und Eigenständigkeit; Portfolio-Agent schlägt maximal drei Experimente vor.  
**Originality:** Nicht Namen, Story, Leveldesign, Figuren, Audio, Grafiken oder prägende Kombinationen übernehmen. Referenzspiele als Analyseobjekte behandeln; kreative Umsetzung aus abstrahierten Designbriefs. Bei erheblicher Ähnlichkeit externe Rechtsprüfung.  
**Satire:** Eindeutig fiktional kennzeichnen; keine unbelegten Tatsachenbehauptungen über reale Personen; keine täuschenden realistischen Fake-Statements.  
**Konfliktthemen:** Fiktive Settings und mehrere Perspektiven bevorzugen, keine ethnischen Stereotype, keine Simulation realer Angriffe als Anleitung.

## 9. Reusable Game Engines und Production Architecture

**Engine families:** Strategy/Hex, Tycoon/Economy, Adventure/Dialog, City/Simulation, Arcade/Tactics. Jeweils Engine Kernel (deterministische Regeln), Content Packs (Szenario, Assets, Texte), UI Themes, Analytics SDK und Export Targets.  
**Technology decision:** Web-first 2D mit TypeScript/Canvas oder Godot-Web für schnelle Iteration; Rust/WASM nur dort, wo Determinismus, Simulation oder Portabilität messbar profitieren. Bevy-Web, Godot und Phaser anhand Ladezeit, Bundlegröße, Mobile-Eingabe, Asset-Pipeline und Agenten-Testbarkeit gegeneinander benchmarken; keine Vorab-Festlegung allein aus Sprachpräferenz.

**Content manifest:** `game_id`, `engine_family`, `mechanics_version`, `theme_pack`, `asset_licenses`, `locale`, `age_rating`, `build_target`, `analytics_schema`, `publisher_approval`, `source_evidence_refs`. Reproduzierbare Builds, Lockfiles, SBOM, SAST, Browser-Smoke-Tests, Screenshot-Diffs und Performance Budgets.

## 10. SkillWeave Multi-Agent Lifecycle

**Agenten:** Controller (GPT/Claude austauschbar), Research, Evidence Verifier, Game Designer, Legal/IP Reviewer (assistiv), Implementation, QA, Publishing, Analytics. SkillWeave steuert Work Items, Artefakte, Review-Gates, Rollbacks und Attestations. REA/Ghidra sind spezialisierte, isolierte Tools.  
**Workflow:** `DISCOVER → EVIDENCE → OPPORTUNITY → DESIGN → ORIGINALITY_GATE → PROTOTYPE → QA → MARKET_TEST → HUMAN_GO → RELEASE → MEASURE → LEARN`.  
**Guardrails:** begrenzte Token-/Compute-Budgets; Least-Privilege; keine automatischen Käufe oder Releases ohne Genehmigung; Testdaten von Produktionsaccounts trennen; Agenten-Outputs mit Provenienz; getrennte Verifier-Modelle; idempotente Tasks und Wiederaufnahme nach Abbruch.

## 11. Publishing, Distribution und Tractioneer

**Own arcade:** SEO-fähige Spielseiten, Instant Play, optionale Accounts, Saves, Events, Discoverability, Kinderschutz-/Privacy-Design, A/B-Tests.  
**Externe Portale:** itch.io, HTML5-Portale nach Aufnahme und SDK-Anforderungen; Steam/native später; Cloud-Gaming wie Luna ist **kein** allgemeiner Browsergame-Uploadkanal und braucht eigenen Zugang/Vertrag.  
**Tractioneer:** Aus Game-Manifesten automatisiert Kurzclips, Creatives und kanalgeeignete Posts erstellen, Freigaben einholen, UTM/Attribution setzen, Publishing-Richtlinien und Anti-Spam-Grenzen beachten. Nicht die Menge der Posts, sondern inkrementelle qualifizierte Spielstarts optimieren.

## 12. Monetization und White Label

**B2C:** Free-to-play, klar gekennzeichnete Werbung, optional werbefreies Abo, Premiumspiele, kosmetische Käufe ohne Pay-to-Win-Zwang.  
**B2B:** Creator Arcades, Publisher Portals, Brand Games, Bildungsversionen, Game-as-a-Service.  
**White-label tenancy:** tenant_id, Domain, Theme, Catalog Policy, Billing, Analytics Partition, Content Moderation, Consent, Data Residency, Quotas, SLA. Mandantentrennung auf Datenbank- und Storage-Ebene prüfen.  
**Pricing:** zunächst Discovery-Interviews; Preisbereiche aus v2.1 bleiben Hypothesen, nicht validierte Zahlungsbereitschaft. Unit Economics: Net Revenue minus Portalshare, Payment Fees, Hosting, Support, Content Updates, Acquisition und Revenue Share.

## 13. Datenarchitektur und Minimal-Schemas

```yaml
mechanic:
  id: mechanic.turn_based_hex_control
  version: 1
  loop: [observe, allocate, move, resolve, feedback]
  evidence_ids: [ev_001]
  abstraction_level: gameplay_pattern
opportunity:
  id: opp_solar_001
  mechanic_ids: [mechanic.resource_investment]
  topic_ids: [topic.energy_transition]
  comparable_ids: []
  evidence_grade: E0
  score: null
  forecast_status: unavailable
  rights_gate: pending
  editorial_gate: pending
experiment:
  id: exp_solar_lp_001
  hypothesis: 'Tycoon framing beats generic energy education framing'
  primary_metric: qualified_play_start_rate
  sample_plan: pending
  stop_rule: pending
  decision: pending
```

**Postgres-Tabellen:** `titles`, `title_identity`, `mechanics`, `loops`, `title_mechanics`, `topics`, `topic_timeseries`, `comparables`, `sources`, `evidence_claims`, `opportunities`, `concepts`, `experiments`, `events`, `cohorts`, `forecasts`, `releases`, `tenants`, `rights_reviews`, `agent_runs`, `audit_log`. Event-Keys pseudonymisiert; Datensparsamkeit, Löschfristen, DSGVO-Rechtsgrundlagen und Consent separat spezifizieren.

## 14. API- und Adapterkontrakte

- `GET /v1/mechanics?genre=...` – versionierte Mechanikprofile.
- `POST /v1/topics/ingest` – Quellen- und Lizenzvalidierung.
- `POST /v1/opportunities/generate` – Kandidaten plus Evidenzlücken.
- `GET /v1/opportunities/{id}/evidence` – zitierfähige Claims.
- `POST /v1/experiments` – preregistrierter Test mit Stop-Regeln.
- `POST /v1/forecasts` – Szenarien oder explizites `insufficient_data`.
- `POST /v1/builds` – reproduzierbarer Build mit Asset-Manifest.
- `POST /v1/releases/request-approval` – niemals implizite Veröffentlichung.
- `GET /v1/analytics/cohorts` – kanalgetrennte Outcomes.

Adapter brauchen Version Pinning, Retry/Rate-Limits, Schema-Checks, Provenienz, ToS-/License-Flags, Degradation bei Ausfällen und einen manuellen Importpfad.

## 15. Portfolio und erste Exposés

**Startportfolio (separate Dateien):** World Order 2100; Autonomous Frontlines; Wind Empire; Solar Dominion; The Alien Administration; Synthetic Gods; Climate City 2100; Tiny Drone Wars; Mars Colonies; Ocean Wars; Climate Exodus.

**Priorisierung vor Evidenz:** Solar Dominion und Tiny Drone Wars für kurze Browserloops; Autonomous Frontlines für differenzierbare Taktik; The Alien Administration als begrenzter Satire-Test. Das ist eine technische/produktstrategische Hypothese, **kein gemessener Demand-Rang**.

**Portfolio-Regel:** maximal zwei parallele Prototypen, ein aktiver Validierungstest; Evergreen- und Trend-Spiele getrennt bewerten. Für Trend Editions gilt zusätzlich ein Time-to-Market-Gate: Wenn das relevante Trendfenster vor Release abläuft, verwerfen oder in Evergreen-Setting umarbeiten.

## 16. Roadmap und Exit Criteria

| Phase | Dauer (Hypothese) | Output | Exit Gate |
|---|---|---|---|
| 0 Foundation | 1–2 Wochen | Identity/Mechanics Registry, Evidence Schema, Source Policy | 20 historische Titel sauber referenziert |
| 1 Intelligence | 2–3 Wochen | 30 moderne Comparables, 20 Topics, GOG MVP | Alle Claims mit Provenienz |
| 2 Opportunity | 1–2 Wochen | Ranking, 11 Exposés, Forecast Skeleton | Keine Scheingenauigkeit, Gates aktiv |
| 3 Prototype | 3–5 Wochen | 2 spielbare Slices, Telemetrie | Reproduzierbare Builds, Smoke Tests |
| 4 Market Test | 2–3 Wochen | Landing-/Playtests, Kanal-Cohorts | Vorab festgelegte Go/No-Go-Regeln |
| 5 Publish | 2–4 Wochen | Arcade MVP + ein externer Kanal | Freigaben, Compliance, Unit Economics |

Zeiten sind **nicht additiv belastbar** und hängen von Team, Toolzugang und Rechteklärung ab. 90-Tage-Ziel: zwei Prototypen, ein freigegebener Browserrelease, ein nachvollziehbarer Demand-Report, erste echte Funnel-Daten.

## 17. Risiken, Gegenmaßnahmen und Entscheidungen

| Risiko | Gegenmaßnahme |
|---|---|
| Nostalgie wird mit Nachfrage verwechselt | moderne Comparables + eigene Conversion-Daten |
| News-Spike wird als Play Intent interpretiert | Mehrquellen- und Retention-Validierung |
| Rechte an historischen Vorbildern unklar | Abstraktion, Rights Registry, Originality Gate |
| KI produziert fehlerhafte/derivative Assets | Herkunftsprüfung, Human Art Review, SBOM/Asset-Ledger |
| Trend-Spiel wirkt zynisch | Editorial Policy, Sensitivity Gate, fiktive Settings |
| Portale akzeptieren Build nicht | Channel Capability Matrix, SDK-Smoke-Tests |
| Automationskosten übersteigen Erlöse | Budget Caps, Cost-per-Validated-Concept |
| White Label erzeugt Supportlast | zuerst Single-Tenant, dann echte Mandantenfähigkeit |
| Forecast überschätzt Verbreitung | Holdout, Kalibrierung, explizite Unsicherheit |

**Offene Architekturentscheidungen:** Game Engine Benchmark; Graphdatenbank versus Postgres-Graphprojektion; erste zwei Genres; Quellenlizenzen; erster Distributionskanal; Analytics/Consent; B2B versus B2C-Reihenfolge; Freigabeprozess für Satire.

## 18. KPI-System

**Intelligence:** Evidence Coverage, Citation Validity, Comparable Freshness, False Trend Rate.  
**Factory:** Median Days-to-Slice, Cost-per-Validated-Concept, QA Regression Rate, Build Reproducibility.  
**Growth:** Qualified Starts, Play Completion, D1/D7, Organic Share, Creator Attribution Lift.  
**Economics:** Net ARPDAU, Contribution Margin, Payback Period, B2B Pipeline, Renewal.  
**Forecast:** Calibration Error, Interval Coverage, Absolute Percentage Error (nur bei nichtnullen Basen).

## 19. Source Register und Verifikation

Dieses Dokument spezifiziert eine **Recherchearchitektur**; es enthält **keine neu erhobenen, titelspezifischen Marktmessungen**. Quellen sind Startpunkte für die spätere Evidence-Ingestion, keine Belege für die Exposé-Nachfrage:

- game Jahresreport: https://www.game.de/publikationen/jahresreport-2026/
- Steamworks Dokumentation: https://partner.steamgames.com/doc/
- Google Trends Hilfe: https://support.google.com/trends/
- Steam Charts: https://steamcharts.com/
- SteamDB: https://steamdb.info/
- itch.io: https://itch.io/
- SkillWeave: https://github.com/SkillWeave-AI/skillweave
- REA: https://github.com/morluto/rea
- Ghidra: https://github.com/NationalSecurityAgency/ghidra

**Verifikationsregel:** API-Verfügbarkeit, Nutzungsbedingungen, Aktualität, Preise und konkrete Repository-Fähigkeiten vor Implementierung erneut prüfen. Öffentliche Trend-/Store-Daten sind häufig nur Proxies und können durch Plattformselektion verzerrt sein.

## 20. Konkrete nächste Deliverables

1. Mechanics Ontology v0.1 mit 20 historischen Titeln und Evidence-IDs.
2. DEIL/TGI Source Adapter Matrix mit rechtlicher Zulässigkeit, Rate Limits, Kosten und Freshness.
3. Opportunity Graph JSON Schema und Postgres-Migration.
4. Forecast Notebook mit Sensitivitätsanalyse und explizitem Missing-Data-Verhalten.
5. Zwei Vertical Slices und preregistrierte Landingpage-Experimente.
6. Publishing Adapter MVP und Tractioneer Attribution Contract.

---
**Dokumentenprinzip:** Annahmen, Evidenz, Prognosen und Entscheidungen bleiben maschinenlesbar getrennt. Ein Score ist kein Beweis; ein Trend ist keine Nachfrage; ein Prototyp ist noch kein Produkt.
