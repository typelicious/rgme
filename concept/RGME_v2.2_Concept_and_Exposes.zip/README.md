# RGME v2.2 — Dokumentenpaket

- `RGME_v2.2_Trend_to_Game_Venture_Studio_Concept.md`: Hauptkonzept.
- `RGME_Expose_*.md`: 11 eigenständige initiale Spiele-Exposés.

**Hinweis:** Die Exposés enthalten Hypothesen und Forschungspläne, keine behaupteten Demand-Messwerte.
